File index.html dan folder images/ di sini adalah default halaman Under
Construction dari MWN. Silakan dihapus jika tidak diperlukan lagi dan Anda
sudah mengisi sendiri dengan file-file website Anda. Pastikan tiap folder
Anda memiliki index.html atau index.php agar dapat dibuka dari browser.
