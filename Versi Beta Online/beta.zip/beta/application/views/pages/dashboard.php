<div class="row" style="background-color:#003399">
				<div class="col-lg-12" >
					
					<h1><font color="white">Dashboard</font></h1>
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<br />
<br />
<div class="row">
	<div class="col-lg-7">
		<div class="row">
                <div class="col-lg-12">
                    <div class="jumbotron">
                        <h2>Selamat Datang, <?php echo($this->session->userdata('email'))?></h2>
                        <p>Selamat menikmati layanan Maktabah Online Versi Beta</p>
						<p><font color = "grey" size="3px">Aplikasi ini masih dalam tahap pengembangan versi beta, jika Anda menemukan kesalahan atau ERROR silahkan melaporkan melalui email did.purwanto@gmail.com serta lampirkan screenshoot error-nya </font></p>
                        
                        </p>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
		
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->